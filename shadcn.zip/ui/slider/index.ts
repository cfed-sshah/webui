export { default as Slider } from './Slider.vue'
